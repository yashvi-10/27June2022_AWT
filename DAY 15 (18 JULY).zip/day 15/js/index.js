$(document).ready(function(){
    $("#dattpatel").draggable();
    $("#datt").droppable({
        accept:'#dattpatel',
        drop:function(event , ui){
            $(this).addClass("myCls").find("p").html("done")
        }
    });

});