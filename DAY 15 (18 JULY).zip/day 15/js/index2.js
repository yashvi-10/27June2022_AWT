$(document).ready(function(){
    $("#mydiv").resizable();

});