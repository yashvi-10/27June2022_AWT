let btn1=document.getElementById('btn1')
let btn2=document.getElementById('btn2')
let btn3=document.getElementById('btn3')
let fontchange=document.getElementById("changefont")

btn1.addEventListener('click',()=>{
    fontchange.classList.add("changefont")
})

btn2.addEventListener('click',()=>{
    fontchange.classList.add('changesize')
})

btn3.addEventListener('click',()=>{
    fontchange.classList.add('hide')
})

btn3.addEventListener('dblclick',()=>{
    fontchange.classList.add('show')
})