let img = document.getElementsByTagName('img')
let img_display = document.getElementsByClassName('img-display')


function shoeing(){
    document.getElementById('new').src="/img/renee-thompson-VdN2CGmvM88-unsplash.jpg";
}

